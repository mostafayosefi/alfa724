<?php

namespace App\Http\Requests\Dashboard\Admin;


class SalaryCreateRequest extends SalaryBaseRequest
{
}
