<?php

namespace App\Http\Requests\Dashboard\Admin;



class TaskCreateRequest extends TaskBaseRequest
{

}
