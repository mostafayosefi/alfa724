
<!-- start footer -->
<footer class="footer">
    <section class="container-xxl my-4">
        <section class="row my-5">
            <section class="col">
                <section class="fw-bold">  سیستم جامع مدیریت وظایف  </section>
                <section class="text-muted footer-intro">

                     همواره تلاش یک سیستم کامل جهت مدیریت کارمندان و ایجاد وظایف در خدمت شما
                </section>
            </section>
        </section>

    </section>
</footer>
<!-- end footer -->

