<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="{{ asset('tamp-mail/css/bootstrap/bootstrap-reboot.rtl.min.css') }}">
<link rel="stylesheet" href="{{ asset('tamp-mail/css/bootstrap/bootstrap.rtl.min.css') }}">
<link rel="stylesheet" href="{{ asset('tamp-mail/fontawesome/css/all.min.css') }}" >
<title> سیستم جامع مدیریت وظایف</title>
