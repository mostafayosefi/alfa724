﻿<x-sidebar-item title="داشبورد" icon="fas fa-tachometer-alt" route="dashboard.customer.index"  ul="false"  />
<x-sidebar-item title="پروفایل" icon="fas fa-user" route="dashboard.profile.edit"  ul="false"  />

