<?php

namespace App\Http\Requests\Dashboard\Employee;


class TaskUpdateRequest extends TaskBaseRequest
{
}
