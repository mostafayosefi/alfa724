<?php

namespace App\Http\Requests\Dashboard\Admin;

class ScoreUpdateRequest extends ScoreBaseRequest
{

}
