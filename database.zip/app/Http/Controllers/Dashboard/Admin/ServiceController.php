<?php

namespace App\Http\Controllers\Dashboard\Admin;

use App\Http\Controllers\Controller;
use App\Models\Salary;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Session\Store;
use App\Models\User;
use App\Models\Project;
use App\Models\Phase;
use App\Models\Customer;
use App\Models\Service;
use App\Models\EmployeeProject;
use App\Models\MyService;
use Illuminate\Auth\Access\Gate;
use Illuminate\Support\Facades\Auth;
use phpDocumentor\Reflection\Types\Null_;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\SoftDeletes;

class ServiceController extends Controller
{

    public function GetCreatePost($id)
    {   $customer = Customer::find($id);
        $users = User::orderBy('created_at', 'desc')->get();
        return view('dashboard.admin.service.create' , compact([   'users'  ,'customer'     ]));

    }

    public function store( $id ,Request $request)
    {


        $request->validate([
            'name' => 'required',
            'durday' => 'required|numeric',
            'price' => 'required',
        ]);
        $data = $request->all();
        $data['startdate'] = convert_shamsi_to_miladi($data['startdate'],'/');
        $data['price'] = str_rep_price($data['price']);
        $data['count'] = 1;
        $data['customer_id'] = $id;
        $data['enddate']  = computing_day_work($data['startdate'],$data['durday']);
       MyService::create($data);
       return redirect()->route('dashboard.admin.customer.show',$id)->with('info', '  سرویس جدید ذخیره شد و نام آن' .' ' . $data['name'] );

    }

    public function show($id)
    {

        $item = MyService::find($id);
        $customer = $item->customer;
        insert_task_in_cleander($item->startdate,$item->enddate,'my_services',$id ,'miladi');
        return view('dashboard.admin.service.show' , compact([   'item'  ,'customer'     ]));


    }

    public function GetManagePost(Request $request)
    {
        $posts = MyService::orderBy('created_at', 'desc')->get();
        return view('dashboard.admin.service.manage', ['posts' => $posts]);
    }

    public function DeletePost($id){
        $post = MyService::find($id);
        $customer=$post->customer_id;
        $post->delete();
        return redirect()->route('dashboard.admin.customer.show',$customer)->with('info', 'خدمت پاک شد');
    }

    public function edit($id)
    {

        $item = MyService::find($id);
        $customer = $item->customer;
        $users = User::orderBy('created_at', 'desc')->get();
         return view('dashboard.admin.service.edit' , compact([   'item'  ,'customer'    ,'users'     ]));

    }

    public function update($id , Request $request)
    {


        $request->validate([
            'name' => 'required',
            'durday' => 'required|numeric',
            'price' => 'required',
        ]);

        $my_service=MyService::find($id);
        $data = $request->all();
        $data['startdate'] = convert_shamsi_to_miladi($data['startdate'],'/');
        $data['price'] = str_rep_price($data['price']);
        $data['enddate']  = computing_day_work($data['startdate'],$data['durday']);

        $data['purdate'] = convert_shamsi_to_miladi($data['purdate'],'/');
        $data['recvdate'] = convert_shamsi_to_miladi($data['recvdate'],'/');

        $my_service->update($data);

        return redirect()->route('dashboard.admin.service.show',$my_service->id)->with('info', 'خدمت ویرایش شد');
    }


}
