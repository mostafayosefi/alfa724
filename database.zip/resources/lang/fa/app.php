<?php

return [
    'status' => [
        'not_done' => 'انجام نشده',
        'notwork' => 'انجام نشده',
        'delayed' => 'به‌تعویق افتاده',
        'in_progress' => 'در حال انجام',
        'done' => 'به‌اتمام رسیده',
        'paid' => 'تسویه شده',
    ]
];
